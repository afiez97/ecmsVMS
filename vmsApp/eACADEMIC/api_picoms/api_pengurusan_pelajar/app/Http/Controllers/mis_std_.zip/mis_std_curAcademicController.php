<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\mis_std_curAcademic;

class mis_std_curAcademicController extends Controller
{
    public function  __construct()
    {
        $this->middleware('auth');
    }

    public function create(Request $request){
        $std_studentid = $request->input('std_studentid');
        $std_semester = $request->input('std_semester');
        $std_duration_study = $request->input('std_duration_study');
        $std_admission = $request->input('std_admission');
        $std_completion = $request->input('std_completion');
        $std_mentor = $request->input('std_mentor');
        $std_senate_endorsement = $request->input('std_senate_endorsement');
        $std_remarks = $request->input('std_remarks');
        $std_gpa = $request->input('std_gpa');
        $std_cgpa = $request->input('std_cgpa');
        $std_cect = $request->input('std_cect');
        $std_total_cect = $request->input('std_total_cect');
        $std_total_credit = $request->input('std_total_credit');
        $std_total_hour = $request->input('std_total_hour');

        if($file = $request->hasFile('std_warning_letter1')){
            $file = $request->file('std_warning_letter1');
            $std_warning_letter1 = $this->uploadFile($file,'_warning_letter1',$std_studentid);               
        }else{
            $std_warning_letter1 = '';
        }

        if($file = $request->hasFile('std_warning_letter2')){
            $file = $request->file('std_warning_letter2');
            $std_warning_letter2 = $this->uploadFile($file,'_warning_letter2',$std_studentid);               
        }else{
            $std_warning_letter2 = '';
        }

        if($file = $request->hasFile('std_warning_letter3')){
            $file = $request->file('std_warning_letter3');
            $std_warning_letter3 = $this->uploadFile($file,'_warning_letter3',$std_studentid);               
        }else{
            $std_warning_letter3 = '';
        }

        $data = [
            'std_studentid'             => $std_studentid,
            'std_semester'              => $std_semester ,
            'std_duration_study'        => $std_duration_study,
            'std_admission'             => $std_admission,
            'std_completion'            => $std_completion,
            'std_mentor'                => $std_mentor,
            'std_senate_endorsement'    => $std_senate_endorsement,
            'std_remarks'               => $std_remarks,
            'std_gpa'                   => $std_gpa,
            'std_cgpa'                  => $std_cgpa,
            'std_cect'                  => $std_cect,
            'std_total_cect'            => $std_total_cect,
            'std_total_credit'          => $std_total_credit,
            'std_total_hour'            => $std_total_hour,
            'std_warning_letter1'       => $std_warning_letter1,
            'std_warning_letter2'       => $std_warning_letter2,
            'std_warning_letter3'       => $std_warning_letter3,
            'recordstatus'              => "ADD",

        ];

        $obj   = mis_std_curAcademic::create($data);

        if($obj){           
            return response()->json([
                'success'=>true,
                'messages'=>'Proses Berjaya',
                'data'=>$obj,
            ],201);
        }
        else {
            return response()->json([
                'success'=>false,
                'messages'=>'Proses Gagal',
                'data'=>'',
            ],400);
        } 
    }

    public function update(Request $request){
        $std_studentid = $request->input('std_studentid');
        $std_semester = $request->input('std_semester');
        $std_duration_study = $request->input('std_duration_study');
        $std_admission = $request->input('std_admission');
        $std_completion = $request->input('std_completion');
        $std_mentor = $request->input('std_mentor');
        $std_senate_endorsement = $request->input('std_senate_endorsement');
        $std_remarks = $request->input('std_remarks');
        $std_gpa = $request->input('std_gpa');
        $std_cgpa = $request->input('std_cgpa');
        $std_cect = $request->input('std_cect');
        $std_total_cect = $request->input('std_total_cect');
        $std_total_credit = $request->input('std_total_credit');
        $std_total_hour = $request->input('std_total_hour');

        $objReg = mis_std_curAcademic::where([['recordstatus','!=','DEL'],['std_studentid','=',$std_studentid]])
        ->where('std_semester',$std_semester)
        ->first();

        if($file = $request->hasFile('std_warning_letter1')){
            $file = $request->file('std_warning_letter1');
            $std_warning_letter1 = $this->uploadFile($file,'_warning_letter1',$std_studentid);               
            if($std_warning_letter1 == ""){
                $std_warning_letter1 = $objReg->std_warning_letter1;
            }
        }else{
            $std_warning_letter1 = $objReg->std_warning_letter1;        }

        if($file = $request->hasFile('std_warning_letter2')){
            $file = $request->file('std_warning_letter2');
            $std_warning_letter2 = $this->uploadFile($file,'_warning_letter2',$std_studentid);               
            if($std_warning_letter2 == ""){
                $std_warning_letter2 = $objReg->std_warning_letter2;
            }
        }else{
            $std_warning_letter2= $objReg->std_warning_letter2;            
        }

        if($file = $request->hasFile('std_warning_letter3')){
            $file = $request->file('std_warning_letter3');
            $std_warning_letter3 = $this->uploadFile($file,'_warning_letter3',$std_studentid);               
            if($std_warning_letter3 == ""){
                $std_warning_letter3 = $objReg->std_warning_letter3;
            }
        }else{
            $std_warning_letter3 = $objReg->std_warning_letter3;
        }

        $data = [
            'std_duration_study'        => $std_duration_study,
            'std_admission'             => $std_admission,
            'std_completion'            => $std_completion,
            'std_mentor'                => $std_mentor,
            'std_senate_endorsement'    => $std_senate_endorsement,
            'std_remarks'               => $std_remarks,
            'std_gpa'                   => $std_gpa,
            'std_cgpa'                  => $std_cgpa,
            'std_cect'                  => $std_cect,
            'std_total_cect'            => $std_total_cect,
            'std_total_credit'          => $std_total_credit,
            'std_total_hour'            => $std_total_hour,
            'std_warning_letter1'       => $std_warning_letter1,
            'std_warning_letter2'       => $std_warning_letter2,
            'std_warning_letter3'       => $std_warning_letter3,
            'recordstatus'              => "EDT",

        ];

        $obj   = mis_std_curAcademic::
        where('std_studentid',$std_studentid)
        ->where('std_semester',$std_semester)
        ->update($data);

        if($obj){  
            $obj = $this->show($std_studentid,$std_semester);         
            return $obj;
        }
        else {
            return response()->json([
                'success'=>false,
                'messages'=>'Proses Gagal',
                'data'=>'',
            ],400);
        }
    }

    public function show($id,$semester){
        $obj   = mis_std_curAcademic::where('std_studentid',$id)
        ->where('std_semester',$semester)
        ->where('recordstatus','!=','DEL')->first();
        if($obj){           
            return response()->json([
                'success'=>true,
                'messages'=>'List Found',
                'data'=>$obj,
            ],200);
        }
        else {
            return response()->json([
                'success'=>false,
                'messages'=>'List Not Found',
                'data'=>'',
            ],200);
        } 
    }

    public function curShow($id){
        $obj   = mis_std_curAcademic::where('std_studentid',$id)
        ->where('recordstatus','!=','DEL')
        ->orderByDesc('std_semester')
        ->first();
        if($obj){           
            return response()->json([
                'success'=>true,
                'messages'=>'List Found',
                'data'=>$obj,
            ],200);
        }
        else {
            return response()->json([
                'success'=>false,
                'messages'=>'List Not Found',
                'data'=>'',
            ],200);
        } 
    }

    public function list(){
        $obj   = mis_std_curAcademic::where('recordstatus','!=','DEL')->get();
        if(sizeof($obj) > 0){           
            return response()->json([
                'success'=>true,
                'messages'=>'List Found',
                'data'=>$obj,
            ],200);
        }
        else {
            return response()->json([
                'success'=>false,
                'messages'=>'List Not Found',
                'data'=>'',
            ],200);
        } 
    }

    public function delete(Request $request){
        $std_studentid = $request->input('std_studentid');
        $obj   = mis_std_curAcademic::where('std_studentid',$std_studentid)->update(["recordstatus" => "DEL"]);
        if($obj){           
            return response()->json([
                'success'=>true,
                'messages'=>'Delete List Success',
                'data'=>$obj,
            ],200);
        }
        else {
            return response()->json([
                'success'=>false,
                'messages'=>'Delete List Fail',
                'data'=>'',
            ],400);
        } 

    }

    public function uploadFile($file,$field,$std_studentid){
        $file_name = "";

        $file_type = $file->getClientOriginalExtension();

        if((strtolower($file_type) == "jpg") || (strtolower($file_type) == "jpeg") || (strtolower($file_type) == "pdf") || (strtolower($file_type) == "png")){
            $file_name = $std_studentid.$field.'.'.$file_type ;
            $destinationPath = 'academic_cur' ;            
            if($file->move($destinationPath,$file_name)){
                //ok
            }
            else{
                $file_name = "";
            }

        }

        return $file_name;
    }
}